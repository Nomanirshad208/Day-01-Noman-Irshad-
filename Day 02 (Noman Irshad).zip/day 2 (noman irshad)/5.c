#include <stdio.h>

int main() {
    int num1, num2;
    
    // Input two numbers from the user
    printf("Enter the first number: ");
    scanf("%d", &num1);
    
    printf("Enter the second number: ");
    scanf("%d", &num2);
    
    // Perform bitwise AND, OR, and XOR
    int bitwise_and = num1 & num2;
    int bitwise_or = num1 | num2;
    int bitwise_xor = num1 ^ num2;
    
    // Perform right shift of the first number by 2 bits
    int right_shift_num1 = num1 >> 2;
    
    // Perform left shift of the second number by 2 bits
    int left_shift_num2 = num2 << 2;
    
    // Display the results
    printf("Bitwise AND: %d\n", bitwise_and);
    printf("Bitwise OR: %d\n", bitwise_or);
    printf("Bitwise XOR: %d\n", bitwise_xor);
    printf("Right shift of the first number by 2: %d\n", right_shift_num1);
    printf("Left shift of the second number by 2: %d\n", left_shift_num2);
    
    return 0;
}
