#include<stdio.h>
int main(){
int a ,b;
printf("enter the length\n");
scanf("%d", &a);
printf("enter the width\n");
scanf("%d", &b);
 printf("area is : %d",a*b);
return 0;




}