#include <stdio.h>

int main(){
 int a,b,c,d,e,f;

 printf("enter first digit \n");
 scanf("%d",&a);

 printf("enter second digit \n");
 scanf("%d",&b);
 
 printf("enter third digit \n");
 scanf("%d",&c);
 
 printf("enter fourth digit \n");
 scanf("%d",&d);

 printf("enter fifth digit \n");
 scanf("%d",&e);
  
  printf("sum is :%d\n",a+b+c+d+e);
 
   printf("average is :%d",(a+b+c+d+e) / 5);


}