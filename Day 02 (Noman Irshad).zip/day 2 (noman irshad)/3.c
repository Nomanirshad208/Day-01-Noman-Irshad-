#include <stdio.h>

int main(){
int num1,num2;

printf("enter first number\n");
scanf("%d",&num1);

printf("enter second number\n");
scanf("%d",&num2);

printf("%d", num1 == num2);
return 0;

}