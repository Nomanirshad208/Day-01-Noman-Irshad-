#include<stdio.h>
 int main(){
 int age;
   printf("enter the age:");
   scanf("%d",&age);

   age >= 18 ? printf("eligible for vote\n") : printf("sorry not eligible for vote");

   return 0;

 }