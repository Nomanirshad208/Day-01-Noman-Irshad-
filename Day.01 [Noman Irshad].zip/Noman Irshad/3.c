#include<stdio.h>

int main()
{
    printf(" ___ \n");
    printf("|___ \n");
    printf("|___");
    return 0;
}