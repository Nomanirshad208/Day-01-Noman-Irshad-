#include<stdio.h>

int main()
{
    printf("This is master in 'C Language' 30 days course \n");
    printf("This course is organised by TECH INVOLVERS");
    return 0;
}